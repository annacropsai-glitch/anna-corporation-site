import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Check, Sparkles } from "lucide-react";

const pricingPlans = [
  {
    name: "One-Time Setup",
    price: "$2,999",
    period: "one-time",
    description: "Perfect for small businesses getting started",
    features: [
      "2 AI Agents of your choice",
      "Basic customization",
      "Email support",
      "30-day money-back guarantee",
      "Halal compliance certification",
      "Setup & training included",
    ],
    popular: false,
  },
  {
    name: "Monthly",
    price: "$299",
    period: "per month",
    description: "Flexible solution for growing businesses",
    features: [
      "All 6 AI Agents included",
      "Advanced customization",
      "Priority support",
      "Monthly performance reports",
      "Halal compliance certification",
      "Free updates & maintenance",
      "Cancel anytime",
    ],
    popular: true,
  },
  {
    name: "Yearly",
    price: "$2,999",
    period: "per year",
    description: "Best value for established businesses",
    features: [
      "All 6 AI Agents included",
      "Full customization",
      "24/7 dedicated support",
      "Weekly performance reports",
      "Halal compliance certification",
      "Free updates & maintenance",
      "2 months free (save $600)",
      "Priority feature requests",
    ],
    popular: false,
  },
];

const Pricing = () => {
  return (
    <section className="py-20 xl:py-32 bg-gradient-to-b from-primary/5 to-background relative overflow-hidden">
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-secondary rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-emerald rounded-full blur-3xl" />
      </div>

      <div className="container relative z-10 mx-auto px-4">
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-4xl xl:text-5xl font-bold text-foreground">
            Simple, Transparent Pricing
          </h2>
          <p className="text-lg xl:text-xl text-muted-foreground max-w-3xl mx-auto">
            Choose the plan that fits your business needs. All plans include 7-day free trial.
          </p>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-8 max-w-7xl mx-auto mb-12">
          {pricingPlans.map((plan, index) => (
            <Card
              key={index}
              className={`relative border-2 ${
                plan.popular
                  ? "border-secondary shadow-glow-gold scale-105"
                  : "border-border shadow-card"
              } bg-card hover:shadow-card-hover transition-all`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-gradient-gold text-secondary-foreground text-sm font-semibold shadow-glow-gold">
                  <Sparkles className="inline w-4 h-4 mr-1" />
                  Most Popular
                </div>
              )}
              <CardHeader className="text-center pb-8 pt-8">
                <CardTitle className="text-2xl font-bold text-foreground mb-2">
                  {plan.name}
                </CardTitle>
                <div className="mb-4">
                  <span className="text-5xl font-bold text-foreground">{plan.price}</span>
                  <span className="text-muted-foreground ml-2">/ {plan.period}</span>
                </div>
                <CardDescription className="text-base">
                  {plan.description}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <ul className="space-y-3">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start gap-3">
                      <Check className="w-5 h-5 text-emerald flex-shrink-0 mt-0.5" />
                      <span className="text-foreground">{feature}</span>
                    </li>
                  ))}
                </ul>
                <Button
                  className={`w-full ${
                    plan.popular
                      ? "bg-secondary text-secondary-foreground hover:bg-secondary/90 shadow-glow-gold"
                      : "bg-primary text-primary-foreground hover:bg-primary/90"
                  }`}
                  size="lg"
                >
                  Start 7-Day Free Trial
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="max-w-4xl mx-auto">
          <Card className="border-2 border-emerald/30 bg-gradient-to-br from-emerald/5 to-transparent">
            <CardContent className="p-8">
              <div className="text-center space-y-4">
                <h3 className="text-2xl font-bold text-foreground">
                  Flexible Payment Options
                </h3>
                <p className="text-muted-foreground">
                  No credit card required for trial • Wise / Bank Transfer available
                </p>
                <div className="flex flex-wrap justify-center gap-4 pt-4">
                  <div className="px-4 py-2 rounded-lg bg-card border border-border">
                    <p className="text-sm font-semibold text-foreground">💳 Wise</p>
                  </div>
                  <div className="px-4 py-2 rounded-lg bg-card border border-border">
                    <p className="text-sm font-semibold text-foreground">🏦 Bank Transfer</p>
                  </div>
                  <div className="px-4 py-2 rounded-lg bg-card border border-border">
                    <p className="text-sm font-semibold text-foreground">💰 Crypto (USDT)</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="text-center mt-12 space-y-4">
          <p className="text-muted-foreground">
            Need a custom solution for your enterprise?
          </p>
          <Button variant="outline" size="lg" className="border-2 border-secondary text-secondary hover:bg-secondary/10">
            Contact Sales
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Pricing;

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Bot, Calendar, MessageSquare, Share2, DollarSign, Heart } from "lucide-react";

const features = [
  {
    icon: Bot,
    title: "AI Receptionist",
    description: "24/7 intelligent customer service that understands and responds in multiple languages",
    benefit: "Reduce response time by 90%",
    color: "text-secondary",
  },
  {
    icon: Calendar,
    title: "Auto Booking",
    description: "Seamless appointment scheduling with automatic calendar integration",
    benefit: "Save 15 hours per week",
    color: "text-emerald",
  },
  {
    icon: MessageSquare,
    title: "Complaint Agent",
    description: "Professional complaint handling with empathy and resolution tracking",
    benefit: "Improve satisfaction by 85%",
    color: "text-secondary",
  },
  {
    icon: Share2,
    title: "Social Manager",
    description: "Automated social media management with halal-compliant content",
    benefit: "3x engagement growth",
    color: "text-emerald",
  },
  {
    icon: DollarSign,
    title: "Halal Finance",
    description: "Riba-free financial management and reporting with full transparency",
    benefit: "100% Shariah compliant",
    color: "text-secondary",
  },
  {
    icon: Heart,
    title: "Donation Agent",
    description: "Streamlined zakat and sadaqah collection with automated receipts",
    benefit: "Increase donations by 60%",
    color: "text-emerald",
  },
];

const Features = () => {
  return (
    <section className="py-20 xl:py-32 bg-background relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-primary/5 to-transparent" />
      
      <div className="container relative z-10 mx-auto px-4">
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-4xl xl:text-5xl font-bold text-foreground">
            Powerful AI Agents for Every Need
          </h2>
          <p className="text-lg xl:text-xl text-muted-foreground max-w-3xl mx-auto">
            Transform your business operations with our suite of intelligent, halal-compliant AI solutions
          </p>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <Card
                key={index}
                className="card-3d border-2 border-border hover:border-secondary/50 bg-card shadow-card group cursor-pointer"
              >
                <CardHeader>
                  <div className="w-16 h-16 rounded-lg bg-gradient-sapphire flex items-center justify-center mb-4 group-hover:shadow-glow-gold transition-all">
                    <Icon className={`w-8 h-8 ${feature.color}`} />
                  </div>
                  <CardTitle className="text-2xl font-bold text-foreground group-hover:text-secondary transition-colors">
                    {feature.title}
                  </CardTitle>
                  <CardDescription className="text-base text-muted-foreground">
                    {feature.description}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-3 rounded-md bg-accent/10 border border-accent/20">
                    <p className="text-sm font-semibold text-accent">
                      ⚡ {feature.benefit}
                    </p>
                  </div>
                  <Button
                    variant="ghost"
                    className="w-full text-secondary hover:text-secondary hover:bg-secondary/10"
                  >
                    See example →
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="text-center mt-16">
          <p className="text-muted-foreground mb-6">
            All agents work together seamlessly to create a complete business automation ecosystem
          </p>
          <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90">
            Explore All Features
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Features;

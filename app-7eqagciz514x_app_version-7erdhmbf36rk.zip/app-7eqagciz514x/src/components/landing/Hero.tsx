import { Button } from "@/components/ui/button";
import { Sparkles, Play } from "lucide-react";
import { useEffect, useState } from "react";

const Hero = () => {
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-hero">
      <div
        className="absolute inset-0 opacity-30"
        style={{
          backgroundImage: `url('https://miaoda-site-img.s3cdn.medo.dev/images/67006e6a-096c-4d86-9059-0a6212123fa0.jpg')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          transform: `translateY(${scrollY * 0.5}px)`,
        }}
      />

      <div className="absolute inset-0 bg-gradient-overlay" />

      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-gold/10 rounded-full blur-3xl animate-pulse-slow" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-emerald/10 rounded-full blur-3xl animate-pulse-slow" style={{ animationDelay: "1s" }} />
      </div>

      <div className="container relative z-10 mx-auto px-4 py-20 text-center">
        <div className="max-w-5xl mx-auto space-y-8">
          <div className="relative inline-block">
            <div className="absolute inset-0 bg-gold/20 blur-3xl rounded-full animate-glow" />
            <div className="relative w-64 h-64 mx-auto mb-8 animate-float">
              <div className="absolute inset-0 rounded-full bg-gradient-sapphire opacity-80 blur-xl" />
              <div className="relative w-full h-full rounded-full border-4 border-gold/30 bg-primary/20 backdrop-blur-sm flex items-center justify-center">
                <div className="w-48 h-48 rounded-full border-2 border-gold/50 bg-primary/10 backdrop-blur-md flex items-center justify-center">
                  <Sparkles className="w-24 h-24 text-secondary animate-pulse-slow" />
                </div>
              </div>
              <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4 bg-gold rounded-full shadow-glow-gold" />
              <div className="absolute top-1/4 right-0 translate-x-1/2 w-4 h-4 bg-emerald rounded-full shadow-glow-emerald" />
              <div className="absolute bottom-1/4 left-0 -translate-x-1/2 w-4 h-4 bg-gold rounded-full shadow-glow-gold" />
              <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-1/2 w-4 h-4 bg-emerald rounded-full shadow-glow-emerald" />
            </div>
          </div>

          <div className="space-y-4">
            <h1 className="text-5xl xl:text-7xl font-bold text-primary-foreground leading-tight">
              Anna Corporation
            </h1>
            <p className="text-2xl xl:text-3xl font-semibold gradient-text">
              Halal. Ethical. Automated. Limitless.
            </p>
          </div>

          <p className="text-lg xl:text-xl text-primary-foreground/90 max-w-3xl mx-auto leading-relaxed">
            Transform your business with AI-powered automation that respects your values. 
            From customer service to financial management, experience the future of halal business operations.
          </p>

          <div className="flex flex-col xl:flex-row gap-4 justify-center items-center pt-8">
            <Button
              size="lg"
              className="bg-secondary text-secondary-foreground hover:bg-secondary/90 shadow-glow-gold text-lg px-8 py-6 group"
              onClick={() => window.open('https://cal.com', '_blank')}
            >
              <Sparkles className="mr-2 h-5 w-5 group-hover:animate-spin" />
              Book AI Demo
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-2 border-secondary text-primary-foreground hover:bg-secondary/10 text-lg px-8 py-6 group"
            >
              <Play className="mr-2 h-5 w-5 group-hover:scale-110 transition-transform" />
              See Live Demo
            </Button>
          </div>

          <div className="pt-8">
            <p className="text-sm xl:text-base text-primary-foreground/80 font-medium">
              ✓ 100% Halal • No Riba • No Human Contact Required
            </p>
          </div>

          <div className="grid grid-cols-2 xl:grid-cols-4 gap-4 pt-12 max-w-4xl mx-auto">
            {[
              { label: "Finance", icon: "💰" },
              { label: "Donation", icon: "🤲" },
              { label: "Complaint", icon: "📋" },
              { label: "Marketing", icon: "📱" },
            ].map((item, index) => (
              <div
                key={index}
                className="p-4 rounded-lg bg-card/10 backdrop-blur-sm border border-gold/20 hover:border-gold/40 transition-all hover:scale-105 cursor-pointer"
              >
                <div className="text-3xl mb-2">{item.icon}</div>
                <p className="text-primary-foreground font-medium">{item.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 rounded-full border-2 border-primary-foreground/30 flex items-start justify-center p-2">
          <div className="w-1 h-2 bg-primary-foreground/50 rounded-full animate-pulse" />
        </div>
      </div>
    </section>
  );
};

export default Hero;

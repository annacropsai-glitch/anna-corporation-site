import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, Star } from "lucide-react";
import { useState } from "react";

const testimonials = [
  {
    name: "Ahmed K.",
    role: "Islamic Finance Director",
    company: "Barakah Holdings",
    content: "Anna Corporation transformed our operations while maintaining complete Shariah compliance. The halal finance module is exceptional.",
    rating: 5,
    avatar: "👨‍💼",
  },
  {
    name: "Fatima S.",
    role: "Charity Director",
    company: "Hope Foundation",
    content: "The donation agent increased our zakat collection by 60% in just 3 months. It's user-friendly and completely transparent.",
    rating: 5,
    avatar: "👩‍💼",
  },
  {
    name: "Omar M.",
    role: "Business Owner",
    company: "Halal Ventures",
    content: "Finally, an AI solution that respects our values. The customer service is available 24/7 without compromising on modesty.",
    rating: 5,
    avatar: "👨",
  },
  {
    name: "Aisha R.",
    role: "Operations Manager",
    company: "Green Crescent",
    content: "The automation saved us 20 hours per week. Everything is halal-certified and the support team is incredibly responsive.",
    rating: 5,
    avatar: "👩",
  },
  {
    name: "Yusuf A.",
    role: "CEO",
    company: "Ethical Tech Solutions",
    content: "Anna Corporation is the future of halal business. The AI agents work seamlessly together and the ROI is outstanding.",
    rating: 5,
    avatar: "👨‍💻",
  },
];

const Testimonials = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const next = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  };

  const prev = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  const getVisibleTestimonials = () => {
    const visible = [];
    for (let i = 0; i < 3; i++) {
      visible.push(testimonials[(currentIndex + i) % testimonials.length]);
    }
    return visible;
  };

  return (
    <section className="py-20 xl:py-32 bg-background relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-emerald/5 to-transparent" />
      
      <div className="container relative z-10 mx-auto px-4">
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-4xl xl:text-5xl font-bold text-foreground">
            Trusted by Halal Businesses Worldwide
          </h2>
          <p className="text-lg xl:text-xl text-muted-foreground max-w-3xl mx-auto">
            Join thousands of businesses that have transformed their operations with Anna Corporation
          </p>
        </div>

        <div className="max-w-7xl mx-auto">
          <div className="hidden xl:grid grid-cols-3 gap-8 mb-8">
            {getVisibleTestimonials().map((testimonial, index) => (
              <Card
                key={index}
                className="border-2 border-border hover:border-secondary/50 bg-card shadow-card transition-all hover:shadow-card-hover"
              >
                <CardContent className="p-6 space-y-4">
                  <div className="flex gap-1">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 fill-secondary text-secondary" />
                    ))}
                  </div>
                  <p className="text-foreground leading-relaxed">
                    "{testimonial.content}"
                  </p>
                  <div className="flex items-center gap-4 pt-4 border-t border-border">
                    <div className="w-12 h-12 rounded-full bg-gradient-sapphire flex items-center justify-center text-2xl">
                      {testimonial.avatar}
                    </div>
                    <div>
                      <p className="font-semibold text-foreground">{testimonial.name}</p>
                      <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                      <p className="text-xs text-muted-foreground">{testimonial.company}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="xl:hidden">
            <Card className="border-2 border-border bg-card shadow-card">
              <CardContent className="p-6 space-y-4">
                <div className="flex gap-1">
                  {[...Array(testimonials[currentIndex].rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-secondary text-secondary" />
                  ))}
                </div>
                <p className="text-foreground leading-relaxed">
                  "{testimonials[currentIndex].content}"
                </p>
                <div className="flex items-center gap-4 pt-4 border-t border-border">
                  <div className="w-12 h-12 rounded-full bg-gradient-sapphire flex items-center justify-center text-2xl">
                    {testimonials[currentIndex].avatar}
                  </div>
                  <div>
                    <p className="font-semibold text-foreground">{testimonials[currentIndex].name}</p>
                    <p className="text-sm text-muted-foreground">{testimonials[currentIndex].role}</p>
                    <p className="text-xs text-muted-foreground">{testimonials[currentIndex].company}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="flex justify-center items-center gap-4 mt-8">
            <Button
              variant="outline"
              size="icon"
              onClick={prev}
              className="rounded-full border-2 border-secondary hover:bg-secondary/10"
            >
              <ChevronLeft className="w-5 h-5 text-secondary" />
            </Button>
            <div className="flex gap-2">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentIndex(index)}
                  className={`w-2 h-2 rounded-full transition-all ${
                    index === currentIndex ? "bg-secondary w-8" : "bg-border"
                  }`}
                  aria-label={`Go to testimonial ${index + 1}`}
                />
              ))}
            </div>
            <Button
              variant="outline"
              size="icon"
              onClick={next}
              className="rounded-full border-2 border-secondary hover:bg-secondary/10"
            >
              <ChevronRight className="w-5 h-5 text-secondary" />
            </Button>
          </div>
        </div>

        <div className="text-center mt-16">
          <div className="inline-flex items-center gap-8 p-6 rounded-2xl bg-gradient-sapphire border border-gold/30">
            <div className="text-center">
              <p className="text-3xl font-bold text-secondary">1000+</p>
              <p className="text-sm text-primary-foreground/80">Active Clients</p>
            </div>
            <div className="w-px h-12 bg-gold/30" />
            <div className="text-center">
              <p className="text-3xl font-bold text-secondary">99.9%</p>
              <p className="text-sm text-primary-foreground/80">Uptime</p>
            </div>
            <div className="w-px h-12 bg-gold/30" />
            <div className="text-center">
              <p className="text-3xl font-bold text-secondary">24/7</p>
              <p className="text-sm text-primary-foreground/80">Support</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;

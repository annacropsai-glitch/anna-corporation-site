import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Play } from "lucide-react";

const DemoVideo = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <section className="py-20 xl:py-32 bg-gradient-to-b from-background to-primary/5">
      <div className="container mx-auto px-4">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12 space-y-4">
            <h2 className="text-4xl xl:text-5xl font-bold text-foreground">
              See Anna in Action
            </h2>
            <p className="text-lg xl:text-xl text-muted-foreground">
              Watch how our AI agents transform business operations in real-time
            </p>
          </div>

          <div className="relative group cursor-pointer" onClick={() => setIsOpen(true)}>
            <div className="absolute inset-0 bg-gradient-sapphire rounded-2xl blur-xl opacity-50 group-hover:opacity-75 transition-opacity" />
            
            <div className="relative aspect-video rounded-2xl overflow-hidden border-4 border-gold/30 bg-gradient-to-br from-primary to-primary-foreground/10 shadow-elegant">
              <div className="absolute inset-0 flex items-center justify-center bg-primary/80 backdrop-blur-sm group-hover:bg-primary/70 transition-all">
                <div className="text-center space-y-6">
                  <div className="relative inline-block">
                    <div className="absolute inset-0 bg-secondary/30 rounded-full blur-2xl animate-pulse-slow" />
                    <div className="relative w-24 h-24 rounded-full bg-secondary flex items-center justify-center shadow-glow-gold group-hover:scale-110 transition-transform">
                      <Play className="w-12 h-12 text-secondary-foreground ml-1" fill="currentColor" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <p className="text-2xl font-bold text-primary-foreground">
                      Watch Demo Video
                    </p>
                    <p className="text-primary-foreground/80">
                      10-minute overview of all features
                    </p>
                  </div>
                </div>
              </div>

              <div className="absolute top-4 left-4 px-4 py-2 rounded-full bg-emerald text-emerald-foreground text-sm font-semibold">
                ✓ Live Demo Available
              </div>
            </div>
          </div>

          <div className="text-center mt-8">
            <p className="text-muted-foreground mb-4">
              AI Demo runs live — book a demo to see your agent in action
            </p>
            <Button
              size="lg"
              className="bg-secondary text-secondary-foreground hover:bg-secondary/90 shadow-glow-gold"
              onClick={() => window.open('https://cal.com', '_blank')}
            >
              Book Your Personal Demo
            </Button>
          </div>
        </div>
      </div>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Anna Corporation Demo</DialogTitle>
            <DialogDescription>
              Experience the power of AI-driven business automation
            </DialogDescription>
          </DialogHeader>
          <div className="aspect-video bg-muted rounded-lg flex items-center justify-center">
            <div className="text-center space-y-4">
              <Play className="w-16 h-16 text-muted-foreground mx-auto" />
              <p className="text-muted-foreground">
                Video player would be embedded here
              </p>
              <p className="text-sm text-muted-foreground">
                Connect your video source (YouTube, Vimeo, or self-hosted)
              </p>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </section>
  );
};

export default DemoVideo;

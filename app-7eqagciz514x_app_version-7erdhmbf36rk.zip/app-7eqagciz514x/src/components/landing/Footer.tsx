import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Sparkles, Mail, MapPin, Phone, Loader2 } from "lucide-react";

const Footer = () => {
  const currentYear = new Date().getFullYear();
  const { toast } = useToast();
  const [email, setEmail] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleNewsletterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const webhookUrl = import.meta.env.VITE_N8N_WEBHOOK_URL || "https://your-n8n-instance.com/webhook/anna/newsletter";
      
      const response = await fetch(webhookUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email,
          source: "newsletter_footer",
          timestamp: new Date().toISOString(),
        }),
      });

      if (response.ok) {
        toast({
          title: "Subscribed Successfully! 🎉",
          description: "Thank you for subscribing to our newsletter.",
        });
        setEmail("");
      } else {
        throw new Error("Failed to subscribe");
      }
    } catch (error) {
      console.error("Newsletter subscription error:", error);
      toast({
        title: "Subscription Failed",
        description: "Please try again later.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <footer className="bg-gradient-hero text-primary-foreground border-t border-gold/20">
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-12 mb-12">
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Sparkles className="w-8 h-8 text-secondary" />
              <span className="text-2xl font-bold">Anna Corporation</span>
            </div>
            <p className="text-primary-foreground/80 leading-relaxed">
              Halal. Ethical. Automated. Limitless.
            </p>
            <p className="text-sm text-primary-foreground/70">
              Transforming businesses with AI-powered automation that respects your values.
            </p>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-secondary">Services</h3>
            <ul className="space-y-2">
              {[
                "AI Receptionist",
                "Auto Booking",
                "Complaint Agent",
                "Social Manager",
                "Halal Finance",
                "Donation Agent",
              ].map((service, index) => (
                <li key={index}>
                  <a
                    href="#"
                    className="text-primary-foreground/80 hover:text-secondary transition-colors"
                  >
                    {service}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-secondary">Company</h3>
            <ul className="space-y-2">
              {[
                { label: "About", href: "#" },
                { label: "Pricing", href: "#" },
                { label: "Contact", href: "#" },
                { label: "Privacy Policy", href: "#" },
                { label: "Terms of Service", href: "#" },
                { label: "Admin Login", href: "#" },
              ].map((item, index) => (
                <li key={index}>
                  <a
                    href={item.href}
                    className="text-primary-foreground/80 hover:text-secondary transition-colors"
                  >
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-secondary">Contact Us</h3>
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <Mail className="w-5 h-5 text-secondary flex-shrink-0 mt-0.5" />
                <a
                  href="mailto:info@annacorp.com"
                  className="text-primary-foreground/80 hover:text-secondary transition-colors"
                >
                  info@annacorp.com
                </a>
              </div>
              <div className="flex items-start gap-3">
                <Phone className="w-5 h-5 text-secondary flex-shrink-0 mt-0.5" />
                <a
                  href="tel:+1234567890"
                  className="text-primary-foreground/80 hover:text-secondary transition-colors"
                >
                  +1 (234) 567-890
                </a>
              </div>
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-secondary flex-shrink-0 mt-0.5" />
                <span className="text-primary-foreground/80">
                  Global Operations
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gold/20 pt-8">
          <div className="flex flex-col xl:flex-row justify-between items-center gap-6">
            <div className="text-center xl:text-left">
              <p className="text-primary-foreground/70 text-sm">
                {currentYear} Anna Corporation
              </p>
              <p className="text-primary-foreground/60 text-xs mt-1">
                ✓ 100% Halal Certified • Shariah Compliant • Ethically Operated
              </p>
            </div>

            <div className="flex flex-col xl:flex-row items-center gap-4">
              <p className="text-sm text-primary-foreground/80">
                Subscribe to our newsletter
              </p>
              <form onSubmit={handleNewsletterSubmit} className="flex gap-2 w-full xl:w-auto">
                <Input
                  type="email"
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  disabled={isSubmitting}
                  className="bg-primary-foreground/10 border-gold/30 text-primary-foreground placeholder:text-primary-foreground/50 w-full xl:w-64"
                />
                <Button 
                  type="submit"
                  disabled={isSubmitting}
                  className="bg-secondary text-secondary-foreground hover:bg-secondary/90 shadow-glow-gold"
                >
                  {isSubmitting ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    "Subscribe"
                  )}
                </Button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

import Hero from "@/components/landing/Hero";
import Features from "@/components/landing/Features";
import DemoVideo from "@/components/landing/DemoVideo";
import Testimonials from "@/components/landing/Testimonials";
import Pricing from "@/components/landing/Pricing";
import ContactForm from "@/components/landing/ContactForm";
import Footer from "@/components/landing/Footer";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Hero />
      <Features />
      <DemoVideo />
      <Testimonials />
      <Pricing />
      <ContactForm />
      <Footer />
    </div>
  );
};

export default Index;
